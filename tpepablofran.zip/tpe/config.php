<?php
const MYSQL = array(
  'USER' => 'root',
  'PASS' => '',
  'DB' => 'noticias_del_ermitano',
  'HOST' => 'localhost',
);