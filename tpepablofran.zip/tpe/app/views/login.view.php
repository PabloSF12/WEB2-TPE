<?php

class LoginView{
  public function showLogin(){
    require './templates/login.phtml';
  }
}